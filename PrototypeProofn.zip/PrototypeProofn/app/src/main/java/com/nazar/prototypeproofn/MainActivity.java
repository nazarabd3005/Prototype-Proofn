package com.nazar.prototypeproofn;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.NavigationView;
import android.support.design.widget.Snackbar;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.RequestOptions;
import com.bumptech.glide.request.target.Target;
import com.esafirm.imagepicker.features.ImagePicker;
import com.esafirm.imagepicker.model.Image;
import com.nazar.prototypeproofn.base.BaseActivity;
import com.nazar.prototypeproofn.common.InboxFragment;
import com.nazar.prototypeproofn.utils.Config;

import java.util.List;

public class MainActivity extends BaseActivity
        implements NavigationView.OnNavigationItemSelectedListener {
    private boolean isInSelectionMode = false;
    //view
    ImageView avatar;
    AlertDialog alertDialog;
    //fragment
    InboxFragment fragment;
    //toolbarItem
    MenuItem menuSearch, menuCompose, menuDelete, menuCancel;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        LinearLayout headerView = (LinearLayout) navigationView.getHeaderView(0);
        avatar = (ImageView) headerView.getChildAt(0);
        avatar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ImagePicker.create(MainActivity.this) // Activity or Fragment
                        .start();
            }
        });
        navigationView.setNavigationItemSelectedListener(this);


        fragment = new InboxFragment();
        getFragmentHelper().replaceFragment(R.id.container, fragment, false);

        initData();
    }

    private void initData() {
        Glide.with(this)
                .load(Config.URL_IMAGE + Config.user.avatarPathSmall).centerInside().apply(RequestOptions.circleCropTransform()).addListener(new RequestListener<Drawable>() {
            @Override
            public boolean onLoadFailed(@Nullable GlideException e, Object model, Target<Drawable> target, boolean isFirstResource) {
                Log.e("GLIDE", e.toString());
                return false;
            }

            @Override
            public boolean onResourceReady(Drawable resource, Object model, Target<Drawable> target, DataSource dataSource, boolean isFirstResource) {
                return false;
            }
        }).into(avatar);
    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else if (isInSelectionMode) {
            fragment.doCancel();
            isInSelectionMode = false;
            toolbarUpdate();
        }else {
            super.onBackPressed();
        }
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        menuDelete = menu.findItem(R.id.delete);
        menuCancel = menu.findItem(R.id.cancel);
        menuSearch = menu.findItem(R.id.search);
        menuCompose = menu.findItem(R.id.compose);
        toolbarUpdate();
        return true;
    }

    public void toolbarUpdate() {
        if (isInSelectionMode) {
            menuDelete.setVisible(true);
            menuCancel.setVisible(true);
            menuCompose.setVisible(false);
            menuSearch.setVisible(false);
        } else {
            menuDelete.setVisible(false);
            menuCancel.setVisible(false);
            menuCompose.setVisible(true);
            menuSearch.setVisible(true);
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.search) {
            return true;
        }

        if (id == R.id.compose) {
            return true;
        }
        if (id == R.id.delete) {
            fragment.doDelete();
            isInSelectionMode = false;
            toolbarUpdate();
            return true;
        }
        if (id == R.id.cancel) {
            fragment.doCancel();
            isInSelectionMode = false;
            toolbarUpdate();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }


    public void setInSelectionMode(boolean inSelectionMode) {
        isInSelectionMode = inSelectionMode;
        toolbarUpdate();
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.navInbox) {
            // Handle the camera action
        } else if (id == R.id.navNeedResponse) {

        } else if (id == R.id.navimportant) {

        } else if (id == R.id.navDraft) {

        } else if (id == R.id.navTrash) {

        } else if (id == R.id.navDll) {

        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    @Override
    protected void onActivityResult(int requestCode, final int resultCode, Intent data) {
        if (ImagePicker.shouldHandle(requestCode, resultCode, data)) {
            // Get a list of picked images
            List<Image> images = ImagePicker.getImages(data);
            // or get a single image only
            Image image = ImagePicker.getFirstImageOrNull(data);
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

}
