package com.nazar.prototypeproofn.models;

import java.util.ArrayList;

public class Message {
    public int id;
    public String hash;
    public String contentType;
    public int messageClass;
    public String[] defaultLabels;
    public int messageType;
    public int recipientID;
    public String recipientEmail;
    public boolean asMain = false;
    public boolean asCC = false;
    public boolean asBCC = false;
    public ArrayList<User> to = new ArrayList<>();
    public Object[] recipients;
    public Object[] recipientsAsCC;
    public Object[] getRecipientsAsBCC;
    public String senderEmail;
    public User sender = new User();
    public String sentAt;
    public String threadID;
    public String inReplyTo;
    public String subjectPreview;
    public String subject;
    public String contentPreview;
    public String content;
    public int attachmentCount;
    public int availabilityStatus;
    public int deliveryStatus;

    //need
    public boolean selected = false;


    public class RequestSend {
        public String subject;
        public String content;
        public String[] recipients;
        public String[] recipientsAsCC;
        public String[] recipientsAsBCC;
        public String contentPreview;
    }

    public class Response extends Message {
        public String message;
    }
}
