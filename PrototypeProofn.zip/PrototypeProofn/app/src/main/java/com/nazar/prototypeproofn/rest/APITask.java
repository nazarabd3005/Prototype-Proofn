package com.nazar.prototypeproofn.rest;

import com.nazar.prototypeproofn.models.Auth;
import com.nazar.prototypeproofn.models.Message;
import com.nazar.prototypeproofn.utils.Config;

import retrofit2.Call;

public class APITask {

    public static void doLogin(Auth.Request request, final RestCallback<Auth.Response> responseRestCallback){
        RestConnect connect = RestService.getInstance().getConnections();
        Call<Auth.Response> call =  connect.login(request);
        call.enqueue(new RestCallback<Auth.Response>() {
            @Override
            public void onSuccess(int code, Auth.Response body) {
                Config.saveAuth(body.token,body.user);
                responseRestCallback.onSuccess(code,body);
            }

            @Override
            public void onFailed(int code, String message) {
                responseRestCallback.onFailed(code,message);
            }
        });
    }

    public static void doInboxDelete(String id, final RestCallback<Message.Response> responseRestCallback){
        RestConnect connect = RestService.getInstance().getConnections();
        Call<Message.Response> call =  connect.inboxDelete(Config.DUMMY_TOKEN,id);
        call.enqueue(new RestCallback<Message.Response>() {
            @Override
            public void onSuccess(int code, Message.Response body) {
                responseRestCallback.onSuccess(code,body);
            }

            @Override
            public void onFailed(int code, String message) {
                responseRestCallback.onFailed(code,message);
            }
        });

    }
}
