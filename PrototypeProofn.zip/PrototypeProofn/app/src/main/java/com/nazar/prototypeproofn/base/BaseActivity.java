package com.nazar.prototypeproofn.base;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;

import com.nazar.prototypeproofn.helpers.FragmentHelper;
import com.nazar.prototypeproofn.utils.Config;

public class BaseActivity extends AppCompatActivity {
    public FragmentHelper fragmentHelper;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        fragmentHelper = new FragmentHelper();
        fragmentHelper.setFragmentManager(getSupportFragmentManager());
        Config.loadAuth();
        super.onCreate(savedInstanceState);

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    @Override
    protected void onStart() {
        super.onStart();

    }


    public FragmentHelper getFragmentHelper() {
        return fragmentHelper;
    }
}
