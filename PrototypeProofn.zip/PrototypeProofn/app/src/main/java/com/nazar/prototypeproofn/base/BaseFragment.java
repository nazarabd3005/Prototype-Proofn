package com.nazar.prototypeproofn.base;

import android.support.v4.app.Fragment;

public class BaseFragment extends Fragment {
}
